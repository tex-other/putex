#define next(H)    hash[H].hh1.lh
#define text(H)    hash[H].hh1.rh
#define font_id_text(H)  text(FONT_ID_BASE + H)

#define hash_is_full  (hash_used == HASH_BASE)

extern twoh hash[];
extern pointer hash_used;
extern bool no_new_control_sequence;
extern int cs_count;

pointer id_lookup (int j, int l);
void print_cs (pointer p);
void sprint_cs (pointer p);

#ifdef INIT
void primitive (char *s, quarterword c, halfword o);
#endif
