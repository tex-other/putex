#define EXACTLY    0
#define ADDITIONAL   1
#define NATURAL    0L, ADDITIONAL

extern pointer  adjust_tail;
extern scaled total_stretch[];
extern scaled total_shrink[];

extern long pack_begin_line;

#define make_char_from_lig() \
 {mem[lig_trick] = mem[lig_char(p)]; \
 link(lig_trick) = link(p); \
 p = lig_trick;}

#define get_stretch_order() \
 {if (total_stretch[FILLL] != 0) o = FILLL; \
 else if (total_stretch[FILL] != 0) o = FILL; \
 else if (total_stretch[FIL] != 0) o = FIL; \
 else o = NORMAL;}
   
#define get_shrink_order() \
 {if (total_shrink[FILLL] != 0) o = FILLL; \
 else if (total_shrink[FILL] != 0) o = FILL; \
 else if (total_shrink[FIL] != 0) o = FIL; \
 else o = NORMAL;}

#define vpack(P, H)   vpackage(P, H, MAX_DIMEN)
pointer vpackage (pointer p, scaled h, int m, scaled l);
pointer hpack (pointer p, scaled w, int m);
