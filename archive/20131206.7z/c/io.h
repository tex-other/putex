
extern int last;
extern ASCII_code buffer[];
extern int first;
extern int max_buf_stack;

FILE *a_open_in (void);
FILE *a_open_out (void);

FILE *b_open_in (void);
FILE *b_open_out (void);

FILE *w_open_in (void);
FILE *w_open_out (void);

#define a_close(FD) (fclose(FD))
#define b_close(FD) (fclose(FD))
#define w_close(FD) (fclose(FD))

#define prompt_input(S) {print(S); term_input();}

bool init_terminal (void);
void term_input (void);
bool input_ln (alpha_file f, bool bypass_eoln);

#define term_in stdin
#define term_out stdout
#define t_open_in()
#define t_open_out()
#define update_terminal() fflush(stdout)
#define clear_terminal()
