#define ABOVE_CODE  0
#define OVER_CODE  1
#define ATOP_CODE  2
#define DELIMITED_CODE 3

void push_math (group c);
void init_math (void);
void start_eq_no (void);
void scan_math (pointer p);
void set_math_char (integer c);
void math_limit_switch (void);
void scan_delimiter (pointer p, bool r);
void math_radical (void);
void math_ac (void);
void append_choices (void);
void build_choices (void);
void sub_sup (void);
void math_fraction (void);
pointer fin_mlist (pointer p);
void math_left_right (void);
void after_math (void);
void resume_after_display (void);
