#define NO_PRINT   16 
#define TERM_ONLY   17
#define LOG_ONLY   18
#define TERM_AND_LOG  19
#define PSEUDO    20
#define NEW_STRING   21
#define MAX_SELECTOR  21

extern alpha_file log_file;

extern int selector;

extern int term_offset;
extern int file_offset;

extern char dig[];
extern integer tally;
extern ASCII_code trick_buf[];
extern integer trick_count;
extern integer first_count;

void print (char *s);
void print_char (ASCII_code c);
//int  print_sym(); not found.
void print_ln (void);
void print_esc (char *s);
void print_nl (char *s);
void print_the_digs (int k);
void print_two (int n);
void print_int (int n);
void print_val (integer n);
void print_hex (integer v);
void print_ASCII (int c);
void print_str (str s);
void slow_print (str s);
void print_roman_int (integer n);
void print_current_string (void);

#define wterm(c)  putchar(c);
#define wterm_ln(c)  {putchar(c); putchar('\n');}
#define wterm_cr()  putchar('\n');

#define wlog(c)   putc(c, log_file)
#define wlog_ln(c)  {putc(c, log_file); putc('\n', log_file);}
#define wlog_cr()  putc('\n', log_file);

#define wfile(c)  putc(c, write_file[selector])
#define wfile_ln(c)  {putc(c, write_file[selector]); \
      putc('\n', write_file[selector]);}
#define wfile_cr()  putc('\n', write_file[selector]);
