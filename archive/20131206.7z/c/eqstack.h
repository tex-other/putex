extern pointer		save_ptr;
extern mword	save_stack[];
extern pointer		max_save_stack;

extern quarterword	cur_level;
extern group	cur_group;
extern pointer		cur_boundary;

#define	save_type(S)			save_stack[S].hh.hh2.b0
#define	save_level(S)			save_stack[S].hh.hh2.b1
#define	save_index(S)			save_stack[S].hh.hh2.rh

#define	RESTORE_OLD_VALUE		0
#define	RESTORE_ZERO			1
#define	INSERT_TOKEN			2
#define	LEVEL_BOUNDARY			3

#define	BOTTOM_LEVEL			0
#define	SIMPLE_GROUP			1
#define	HBOX_GROUP				2
#define	ADJUSTED_HBOX_GROUP		3
#define	VBOX_GROUP				4
#define	VTOP_GROUP				5
#define	ALIGN_GROUP				6
#define	NO_ALIGN_GROUP			7
#define	OUTPUT_GROUP			8
#define	MATH_GROUP				9
#define	DISC_GROUP				10
#define	INSERT_GROUP			11
#define	VCENTER_GROUP			12
#define	MATH_CHOICE_GROUP		13
#define	SEMI_SIMPLE_GROUP		14
#define	MATH_SHIFT_GROUP		15
#define	MATH_LEFT_GROUP			16
#define	MAX_GROUP_CODE			16

#define	saved(I)	save_stack[save_ptr + I].i

void new_save_level (group c);
void eq_destroy (mword w);
void eq_save (pointer p, quarterword l);
void eq_define (pointer p, quarterword t, halfword e);
void eq_word_define (pointer p, integer w);
void geq_define (pointer p, quarterword t, halfword e);
void geq_word_define (pointer p, integer w);
void save_for_after (halfword t);
void unsave (void);
void off_save (void);

#ifdef STAT
void restore_trace (pointer p, char *s);
#endif
