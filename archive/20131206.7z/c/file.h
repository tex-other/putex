extern char name_of_file[];
extern int  name_length;

extern str  cur_name;
extern str  cur_area;
extern str  cur_ext;

extern int  area_delimiter;
extern int  ext_delimiter;

#define MAX_PATH_CHARS 1024

extern char input_path[];
extern char format_path[];
extern char font_path[];

void begin_name (void);
bool more_name (ASCII_code c);
void end_name (void);
void set_paths (void);
void copy_path (char *s1, char *s2, int n);
void set_def_area(void);
bool test_access (int amode, int file_path);
void get_real_name (void);

#define default_font_path   ".:/usr/lib/tex/fonts"
#define default_format_path ".:/usr/lib/tex/macros"
#define default_input_path  ".:/usr/lib/tex/macros"

void print_file_name (str n, str a, str e);
void pack_file_name (str n, str a, str e);

#define TeX_format_default "plain.fmt"

bool open_fmt_file (void);
void pack_buffered_name (int a, int b);

str make_name_string (void);
void write_name_string (void);

#define a_make_name_string(f) make_name_string()
#define b_make_name_string(f) make_name_string()
#define w_make_name_string(f) make_name_string()

extern bool name_in_progress;
extern bool log_opened;
void scan_file_name (void);

#define pack_cur_name() \
 {pack_file_name(cur_name, cur_area, cur_ext);}

void pack_job_name (str s);
void prompt_file_name (char *s, str e);

extern str dvi_name;

extern str  job_name;
extern str  job_area;
extern str  log_name;

void open_log_file (void);
void start_input (void);

extern alpha_file read_file[];
extern int  read_open[];

#define JUST_OPENED   1
#define CLOSED    2

bool test_access();

#define READ_ACCESS   4
#define WRITE_ACCESS   2

#define NO_FILE_PATH   0
#define INPUT_FILE_PATH  1
#define FONT_FILE_PATH   2
#define FORMAT_FILE_PATH  3

extern str  str_dvi;
extern str  str_tex;
extern str  str_log;
extern str  str_tfm;
extern str  str_fmt;
extern str  str_texput;

#ifdef INIT
void init_file (void);
#endif
