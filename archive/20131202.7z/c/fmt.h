
/*
 *    Copyright 1986, 1987 Pat Joseph Monardo. All rights reserved.
 *    Copying of this file is granted according to the provisions 
 *    specified in the file COPYING which must accompany this file.
 */


/*
 *		fmt.h
 */

global	word_file	fmt_file;

global	str	format_ident;

bool	load_fmt_file();

#ifdef INIT
int		store_fmt_file();
#endif
