
/*
 *    Copyright 1986, 1987 Pat Joseph Monardo. All rights reserved.
 *    Copying of this file is granted according to the provisions 
 *    specified in the file COPYING which must accompany this file.
 *    Copying of this file is granted according to the provisions 
 *    specified in the file COPYING which must accompany this file.
 */


/*
 *		eval.h
 */

int		main_control();
int		app_space();
int		insert_dollar_sign();
int		you_cant();
int		report_illegal_case();
bool	privileged();
int		missing_font();
bool	its_all_over();
