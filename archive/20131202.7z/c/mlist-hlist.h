
/*
 *    Copyright 1986, 1987 Pat Joseph Monardo. All rights reserved.
 *    Copying of this file is granted according to the provisions 
 *    specified in the file COPYING which must accompany this file.
 */


/*
 *		mlist-hl.h
 */

global	qword	cur_c;
global	fnt		cur_f;
global	fourq	cur_i;
global	ptr		cur_mlist;
global	scal	cur_mu;
global	int		cur_size;
global	int		cur_style;
global	bool	mlist_penalties;

ptr		clean_box();
int		fetch();

#define	new_hlist(N)			mem[nucleus(N)].i

int		mlist_to_hlist();

int		make_over();
int		make_under();
int		make_vcenter();
int		make_radical();
int		make_math_accent();
int		make_fraction();
scal	make_op();
int		make_ord();
int		make_scripts();
int		make_left_right();

global	int	magic_offset;
