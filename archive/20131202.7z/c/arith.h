#define	UNITY 0200000
#define	TWO 0400000

val half (val x);
scal round_decimals (int k);
void print_scaled (scal s);

global bool arith_error;
global scal texremainder;

scal nx_plus_y (val n, scal x, scal y);
scal x_over_n (scal x, val n);
scal xn_over_d (scal x, val n, val d);

#define	INF_BAD 10000 

hword badness (scal t, scal s);
