
/*
 *    Copyright 1986, 1987 Pat Joseph Monardo. All rights reserved.
 *    Copying of this file is granted according to the provisions 
 *    specified in the file COPYING which must accompany this file.
 */


/*
 *		hash.h
 */

#define	next(H)				hash[H].hh1.lh
#define	text(H)				hash[H].hh1.rh
#define	font_id_text(H)		text(FONT_ID_BASE + H)

#define	hash_is_full		(hash_used == HASH_BASE)

global	twoh	hash[];
global	ptr		hash_used;
global	bool	no_new_control_sequence;
global	int		cs_count;

ptr		id_lookup();
int		print_cs();
int		sprint_cs();

#ifdef	INIT
int		primitive();
#endif
