global	ascii	xord[];

#define	FIRST_ASCII_CODE		0
#define	LAST_ASCII_CODE			127

global 	char	xchr[];

#define	FIRST_TEXT_CHAR			0
#define	LAST_TEXT_CHAR			127

#define	TAB						011
#define FORM_FEED				014
#define	CARRIAGE_RETURN			015
#define	NULL_CODE				000
#define	INVALID_CODE			0177

void init_char (void);
