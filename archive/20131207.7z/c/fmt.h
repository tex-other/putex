extern word_file fmt_file;
extern str format_ident;
bool load_fmt_file (void);

#ifdef INIT
void store_fmt_file (void);
#endif
