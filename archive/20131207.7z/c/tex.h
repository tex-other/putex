#include <stdio.h>
#include <signal.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

#define NUL     '\0'
#define EOLN    '\n'
#define FALSE   0
#define TRUE    1
#define EMPTY   0

#define BUF_SIZE          5000
#define DVI_BUF_SIZE      1024
#define ERROR_LINE        78
#define FILE_NAME_SIZE    104
#define FONT_BASE         0
#define FONT_MAX          100
#define FONT_MEM_SIZE     25000
#define HALF_BUF          512
#define HALF_ERROR_LINE   39
#define HASH_SIZE         3000
#define HASH_PRIME        2551
#define HYPH_SIZE         307
#define MAX_IN_OPEN       15
#define MAX_PRINT_LINE    78
#define MAX_STRINGS       5400
#define NEST_SIZE         40
#define PARAM_SIZE        30
#define POOL_SIZE         25000
#define SAVE_SIZE         600
#define STACK_SIZE        200
#define STRING_VACANCIES  1000
#define TRIE_OP_HASH_SIZE 512
#define TRIE_SIZE         8000

#ifdef INIT
#if !defined(BIGG) && !defined(BIG)
#define MEM_BOT    0
#define MEM_TOP     17000
#define TOK_BOT    0
#define TOK_TOP    27000
#define MEM_MIN    MEM_BOT
#define MEM_MAX    MEM_TOP
#define TOK_MIN    TOK_BOT
#define TOK_MAX    TOK_TOP
#define MIN_QUARTERWORD  0
#define MAX_QUARTERWORD  255
#define MIN_HALFWORD  0
#define MAX_HALFWORD  65535
#endif

#ifdef BIG
#define MEM_BOT    0
#define MEM_TOP     27000
#define TOK_BOT    0
#define TOK_TOP    37000
#define MEM_MIN    MEM_BOT
#define MEM_MAX    MEM_TOP
#define TOK_MIN    TOK_BOT
#define TOK_MAX    TOK_TOP
#define MIN_QUARTERWORD  0
#define MAX_QUARTERWORD  255
#define MIN_HALFWORD  0
#define MAX_HALFWORD  655350
#endif

#ifdef BIGG
#define MEM_BOT    0
#define MEM_TOP     37000
#define TOK_BOT    0
#define TOK_TOP    47000
#define MEM_MIN    MEM_BOT
#define MEM_MAX    MEM_TOP
#define TOK_MIN    TOK_BOT
#define TOK_MAX    TOK_TOP
#define MIN_QUARTERWORD  0
#define MAX_QUARTERWORD  255
#define MIN_HALFWORD  0
#define MAX_HALFWORD  6553500
#endif

#else 

#if !defined(BIGG) && !defined(BIG)
#define MEM_BOT    0
#define MEM_TOP     17000
#define TOK_BOT    0
#define TOK_TOP    27000
#define MEM_MIN    0
#define MEM_MAX    32000
#define TOK_MIN    0
#define TOK_MAX    35000
#define MIN_QUARTERWORD  0
#define MAX_QUARTERWORD  255
#define MIN_HALFWORD  0
#define MAX_HALFWORD  65535
#endif

#ifdef BIG
#define MEM_BOT    0
#define MEM_TOP     27000
#define TOK_BOT    0
#define TOK_TOP    37000
#define MEM_MIN    0
#define MEM_MAX    128000
#define TOK_MIN    0
#define TOK_MAX    45000
#define MIN_QUARTERWORD  0
#define MAX_QUARTERWORD  255
#define MIN_HALFWORD  0
#define MAX_HALFWORD  655350
#endif

#ifdef BIGG
#define MEM_BOT    0
#define MEM_TOP     37000
#define TOK_BOT    0
#define TOK_TOP    47000
#define MEM_MIN    0
#define MEM_MAX    256000
#define TOK_MIN    0
#define TOK_MAX    65000
#define MIN_QUARTERWORD  0
#define MAX_QUARTERWORD  255
#define MIN_HALFWORD  0
#define MAX_HALFWORD  6553500
#endif

#endif

typedef unsigned char ASCII_code;
#define bool int
//#define byte unsigned char
typedef unsigned char byte;
typedef unsigned char eight_bits;
typedef int internal_font_number;
//#define gord unsigned char
typedef unsigned char glue_ord;
//#define gratio float
typedef float glue_ratio;
//typedef float gratio;
typedef int group_code;
#define sc i
typedef long scaled;
typedef long scal;
//#define str hword
//#define val long
typedef long integer;
typedef long val;

typedef FILE *word_file;
typedef FILE *alpha_file;
typedef FILE *byte_file;

typedef unsigned char quarterword;
typedef unsigned char qword;

#if defined(BIG) || defined(BIGG)
typedef unsigned long hword;
typedef unsigned long halfword;
#else
typedef unsigned short hword;
typedef unsigned short halfword;
#endif

typedef halfword pointer;
typedef halfword str;

typedef union { 
  struct { 
    halfword rh; 
    halfword lh; 
  } hh1; 
  struct { 
    halfword rh; 
    quarterword b0; 
    quarterword b1; 
  } hh2; 
} two_halves;

typedef struct { 
  quarterword b0;
  quarterword b1;
  quarterword b2;
  quarterword b3;
} four_quarters;

typedef union { 
  long i;
  glue_ratio gr;
  two_halves hh;  
  four_quarters qqqq;
} mword;

extern char banner[];
extern int  ready_already;

void final_cleanup (void);
void close_files_and_terminate (bool edit);
integer begin_time (void);
void initialize (void);
bool decode_args (int argc, char **argv);
void fix_date_and_time (void);
void handle_int (int sig);

#define incr(i)   ++(i)
#define decr(i)   --(i)
#define odd(i)    ((i) & 1)
#define abs(i)    ((i) >= 0 ? (i) : -(i))
#define round(x)  (long) ((x) > 0.0 ? ((x) + 0.5) : ((x) - 0.5))
#define negate(x) (x) = -(x)
#define loop      while (1)
