#define OPEN_NODE   0
#define open_name(M)  link(M + 1)
#define open_area(M)  info(M + 2)
#define open_ext(M)   link(M + 2)
#define OPEN_NODE_SIZE  3

#define WRITE_NODE   1
#define write_tokens(M)  link(M + 1)
#define write_stream(M)  info(M + 1)
#define WRITE_NODE_SIZE  2

#define CLOSE_NODE   2
#define SPECIAL_NODE  3

#define IMMEDIATE_CODE  4
#define END_WRITE_TOKEN  CS_TOKEN_FLAG + END_WRITE

extern alpha_file write_file[];

extern bool write_open[];
extern pointer write_loc;

void do_extension (void);

void new_whatsit (int s, int w);
void show_whatsit (pointer p);
void free_whatsit (pointer p);
pointer copy_whatsit (pointer p);
void out_whatsit (pointer p);
void new_write (int w);
void print_write (char *s, pointer p);
void out_write (pointer p);
void out_special (pointer p);
