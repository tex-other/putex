void append_glue (void);

enum {
FIL_CODE  = 0,
FILL_CODE  = 1,
SS_CODE   = 2,
FIL_NEG_CODE = 3,
SKIP_CODE  = 4,
MSKIP_CODE  = 5
};

void append_kern (void);

void handle_right_brace (void);
void extra_right_brace (void);

extern pointer cur_box;

void begin_box (void);
void scan_box (void);
void scan_spec (void);
void package (int c);
void box_end (void);

#define BOX_FLAG   010000000000
#define SHIP_OUT_FLAG  (BOX_FLAG + 512)
#define LEADER_FLAG   (BOX_FLAG + 513)
#define BOX_CODE   0
#define COPY_CODE   1
#define LAST_BOX_CODE  2
#define VSPLIT_CODE   3
#define VTOP_CODE   4

void normal_paragraph (void);
void new_graf (bool indented);
void indent_in_hmode (void);
void head_for_vmode (void);
void end_graf (void);
void append_to_vlist (pointer b);
void begin_insert_or_adjust (void);
void make_mark (void);
void append_penalty (void);
//void delete_last (void);
//int delete_skip();
void unpackage (void);
void append_italic_correction (void);
void append_discretionary (void);
void build_discretionary (void);
void make_accent (void);
void align_error (void);
void no_align_error (void);
void omit_error (void);
void do_endv (void);
void cs_error (void);
