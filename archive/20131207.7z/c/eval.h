void main_control (void);
void app_space (void);
void insert_dollar_sign (void);
void you_cant (void);
void report_illegal_case (void);
bool privileged (void);
bool its_all_over (void);
