extern halfword after_token;
extern bool     long_help_seen;
extern integer  mag_set;

void get_r_token (void);
void prefixed_command (void);

enum {
  CHAR_DEF_CODE      = 0,
  MATH_CHAR_DEF_CODE = 1,
  COUNT_DEF_CODE     = 2,
  DIMEN_DEF_CODE     = 3,
  SKIP_DEF_CODE      = 4,
  MU_SKIP_DEF_CODE   = 5,
  TOKS_DEF_CODE      = 6
};

void do_register_command (int a);
void trap_zero_glue (void);
void alter_aux(void);
void alter_prev_graf (void);
void alter_page_so_far (void);
void alter_integer (void);
void alter_box_dimen (void);
void new_font (int a);
void prepare_mag (void);
void new_interaction (void);
void do_assignments (void);
void clopen_stream (void);
void issue_message (void);
void give_err_help (void);
void shift_case (void);
void show_whatever (void);

enum {
  SHOW_CODE     = 0,
  SHOW_BOX_CODE = 1,
  SHOW_THE_CODE = 2,
  SHOW_LISTS    = 3
};
