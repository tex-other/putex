extern pointer  ha;
extern pointer  hb;
extern halfword hc[];
extern int  hn;
extern internal_font_number hf;
extern ASCII_code hu[];
extern int  hyf_char;

void hyphenate (void);

extern byte hyf[];
extern int  hyphen_passed;

int reconstitute (int j, int n);

#define trie_link(T)  trie[T].hh2.rh
#define trie_char(T)  trie[T].hh2.b1
#define trie_op(T)   trie[T].hh2.b0

extern two_halves trie[];
extern quarterword trie_op_ptr;
extern int  trie_max;

extern int  hyf_distance[];
extern int  hyf_num[];
extern quarterword hyf_next[];

void new_hyph_exceptions (void);

extern str  hyph_word[];
extern pointer  hyph_list[];
extern int  hyph_count;

#ifdef INIT

extern quarterword trie_op_hash[];
extern int  trie_min;

qword new_trie_op (int d, int n, quarterword v);

#define trie_root  trie_l[0]

extern int  trie_ptr;
extern ASCII_code trie_c[];
extern quarterword trie_o[];
extern int  trie_l[];
extern int  trie_r[];

extern int  trie_hash[];

int trie_node (int p);
int compress_trie (int p);

void init_pattern_memory (void);

#define trie_ref   trie_hash
#define trie_back(T)  trie[T].hh1.lh

extern bool trie_taken[];

void init_trie_memory (void);

void first_fit (int p);
void trie_pack (int p);
void trie_fix (int p);

void new_patterns (void);

#endif

void init_hyph (void);
