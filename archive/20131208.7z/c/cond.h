extern pointer cond_ptr;
extern int     cur_if;
extern int     if_limit;
extern integer if_line;

#define IF_NODE_SIZE  2
#define if_line_field(M) mem[M + 1].i

enum {
  IF_CODE   = 1,
  FI_CODE   = 2,
  ELSE_CODE = 3,
  OR_CODE   = 4
};

enum {
  IF_CHAR_CODE  = 0,
  IF_CAT_CODE   = 1,
  IF_INT_CODE   = 2,
  IF_DIM_CODE   = 3,
  IF_ODD_CODE   = 4,
  IF_VMODE_CODE = 5,
  IF_HMODE_CODE = 6,
  IF_MMODE_CODE = 7,
  IF_INNER_CODE = 8,
  IF_VOID_CODE  = 9,
  IF_HBOX_CODE  = 10,
  IF_VBOX_CODE  = 11,
  IFX_CODE      = 12,
  IF_EOF_CODE   = 13,
  IF_TRUE_CODE  = 14,
  IF_FALSE_CODE = 15,
  IF_CASE_CODE  = 16
};

void push_cond (void);
void pop_cond (void);
void pass_text (void);
void change_if_limit (int l, pointer p);
void conditional (void);

extern long skip_line;
