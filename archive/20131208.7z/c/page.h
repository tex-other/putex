extern pointer  last_page_glue;

#define active_height active_width
#define cur_height  active_height[1]

pointer prune_page_top (pointer p);

extern scaled best_height_plus_depth;
#define DEPLORABLE  100000

pointer vert_break (pointer p, scaled h, scaled d);
pointer vsplit (int n, scaled h);

extern pointer  page_tail;
extern int  page_contents;

#define INSERTS_ONLY 1
#define BOX_THERE  2

extern pointer  best_page_break;
extern scaled best_size;
extern scaled page_max_depth;
extern integer  least_page_cost;

#define INSERTING    0
#define SPLIT_UP    1
#define broken_ptr(N)   link(N + 1)
#define broken_ins(N)   info(N + 1)
#define last_ins_ptr(N)   link(N + 2)
#define best_ins_ptr(N)   info(N + 2)
#define PAGE_INS_NODE_SIZE  4

extern scaled page_so_far[];

#define page_goal page_so_far[0]
#define page_total page_so_far[1]
#define page_shrink page_so_far[6]
#define page_depth page_so_far[7]

extern pointer  last_glue;
extern integer  last_penalty;
extern scaled last_kern;
extern integer  insert_penalties;

#define start_new_page() \
 {page_contents = EMPTY; \
 page_tail = page_head; \
 link(page_head) = NULL; \
 last_glue = MAX_HALFWORD; \
 last_penalty = 0; \
 last_kern = 0; \
 page_depth = 0; \
 page_max_depth = 0;}

void freeze_page_specs (int s);

extern bool output_active;

void ensure_vbox (int n);
void box_error (int n);
void print_plus (int s, char *o);
void print_totals (void);
#ifdef STAT
void show_split(int n, scaled w, pointer q);
void show_page_stats (integer b, integer p, integer c)
#endif
void build_page (void);
void fire_up (pointer c);

#define contrib_tail   nest[0].tail_field
