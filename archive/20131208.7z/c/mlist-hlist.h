extern quarterword cur_c;
extern internal_font_number cur_f;
extern four_quarters cur_i;
extern pointer  cur_mlist;
extern scaled cur_mu;
extern int  cur_size;
extern int  cur_style;
extern bool mlist_penalties;

pointer clean_box (pointer p, int s);
void fetch (pointer a);

#define new_hlist(N)   mem[nucleus(N)].i

void mlist_to_hlist (void);
void make_over (pointer q);
void make_under (pointer q);
void make_vcenter (pointer q);
void make_radical (pointer q);
void make_math_accent (pointer q);
void make_fraction (pointer q);
scaled make_op (pointer q);
void make_ord (pointer q);
void make_scripts (pointer q, scaled delta);
int make_left_right (pointer q, int style, scaled max_d, scaled max_h);

extern int magic_offset;
