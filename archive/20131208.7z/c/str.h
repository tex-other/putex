extern pointer str_start[];
extern str  str_ptr;

extern ASCII_code str_pool[];
extern pointer pool_ptr;

extern str  null_str;

#define length(S)   (str_start[S + 1] - str_start[S])
#define cur_length()  (pool_ptr - str_start[str_ptr])

#define append_char(C)   {str_pool[pool_ptr] = C; incr(pool_ptr);}
#define flush_char()  decr(pool_ptr)

#define str_room(S) \
 {if (pool_ptr + S >= POOL_SIZE) \
  overflow("pool_size", POOL_SIZE);}

str make_string (void);
str make_string_given (char *s);

#define flush_string() \
 {decr(str_ptr); pool_ptr = str_start[str_ptr];}

bool str_eq_buf (str s, int k);
bool str_eq_str (str s, str t);

void init_strings (void);
