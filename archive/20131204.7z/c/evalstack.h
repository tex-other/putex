#define	VMODE		1
#define	HMODE		(VMODE + MAX_COMMAND + 1)
#define	MMODE		(HMODE + MAX_COMMAND + 1)

void push_nest (void);
void pop_nest (void);
void print_mode (int m);

#define	IGNORE_DEPTH	-65536000

typedef struct
{
	int		mode_field;
	ptr		head_field;
	ptr		tail_field;
	int		pg_field;
	val		aux_field;
	val		ml_field;
} list;

extern list cur_list;
extern ptr nest_ptr;
extern list nest[];
extern int max_nest_stack;

#define	mode				cur_list.mode_field
#define	head				cur_list.head_field
#define	tail				cur_list.tail_field
#define	prev_graf			cur_list.pg_field
#define	aux					cur_list.aux_field
#define	prev_depth			aux
#define	space_factor		aux
#define	incompleat_noad		aux
#define	mode_line			cur_list.ml_field

extern int shown_mode;

void show_activities (void);

#define	tail_append(N) \
	{link(tail) = N; tail = link(tail);}
