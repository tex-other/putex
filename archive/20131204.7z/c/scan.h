void scan_left_brace (void);
void scan_optional_equals (void);
bool scan_keyword (char *s);

global	val		cur_val;
global	int		cur_val_level;

void scan_something_internal (int level, bool negative);

#define	INT_VAL			0
#define	DIMEN_VAL		1
#define	GLUE_VAL		2
#define	MU_VAL			3
#define	IDENT_VAL		4
#define	TOK_VAL			5

void scan_eight_bit_int (void);
void scan_seven_bit_int (void);
void scan_four_bit_int (void);
void scan_char_num (void);
void scan_fifteen_bit_int (void);
void scan_twenty_seven_bit_int (void);

void scan_int (void);
#define INFINITY	017777777777

global	int		radix;

#define	PLUS_TOKEN			(OTHER_TOKEN + '+')
#define	MINUS_TOKEN			(OTHER_TOKEN + '-')
#define	ZERO_TOKEN			(OTHER_TOKEN + '0')
#define	A_TOKEN				(LETTER_TOKEN + 'A')
#define	OTHER_A_TOKEN		(OTHER_TOKEN + 'A')
#define	OCTAL_TOKEN			(OTHER_TOKEN + '\'')
#define	HEX_TOKEN			(OTHER_TOKEN + '"')
#define	ALPHA_TOKEN			(OTHER_TOKEN + '`')
#define	POINT_TOKEN			(OTHER_TOKEN + '.')
#define	EURO_POINT_TOKEN	(OTHER_TOKEN + ',')

void scan_dimen (bool mu, bool inf, bool shortcut);
#define	MAX_DIMEN	07777777777

#define	scan_normal_dimen()		scan_dimen(FALSE, FALSE, FALSE)

global	gord	cur_order;
void scan_glue (int level);

#define	scan_optional_space() \
	{get_x_token(); if (cur_cmd != SPACER) back_input();}

#define	get_nbx_token() \
	{do get_x_token(); while (cur_cmd == SPACER);}

#define	get_nbrx_token() \
	{do get_x_token(); while (cur_cmd == SPACER || cur_cmd == RELAX);}

pointer scan_rule_spec (void);
#define	DEFAULT_RULE	26215
