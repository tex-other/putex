global	char	name_of_file[];
global	int		name_length;

global	str		cur_name;
global	str		cur_area;
global	str		cur_ext;

global	int		area_delimiter;
global	int		ext_delimiter;

#define	MAX_PATH_CHARS	1024

global	char	input_path[];
global	char	format_path[];
global	char	font_path[];

void begin_name (void);
bool more_name (ASCII_code c);
void end_name (void);
void set_paths (void);
void copy_path (char *s1, char *s2, int n);
void set_def_area(void);
bool test_access (int amode, int file_path);
void get_real_name (void);

#define default_font_path   ".:/usr/lib/tex/fonts"
#define default_format_path ".:/usr/lib/tex/macros"
#define default_input_path  ".:/usr/lib/tex/macros"

void print_file_name (str n, str a, str e);
void pack_file_name (str n, str a, str e);

#define	TeX_format_default "plain.fmt"

bool open_fmt_file (void);
void pack_buffered_name (int a, int b);

str make_name_string (void);
void write_name_string (void);

#define	a_make_name_string(f) make_name_string()
#define	b_make_name_string(f) make_name_string()
#define	w_make_name_string(f) make_name_string()

global	bool	name_in_progress;
void scan_file_name (void);

#define	pack_cur_name() \
	{pack_file_name(cur_name, cur_area, cur_ext);}

void pack_job_name (str s);
void prompt_file_name (char *s, str e);

global	str	dvi_name;

global	str		job_name;
global	str		job_area;
global	str		log_name;

void open_log_file (void);
void start_input (void);

global	alpha_file	read_file[];
global	int		read_open[];

#define	JUST_OPENED			1
#define	CLOSED				2

bool	test_access();

#define READ_ACCESS			4
#define WRITE_ACCESS 		2

#define NO_FILE_PATH 		0
#define INPUT_FILE_PATH 	1
#define FONT_FILE_PATH 		2
#define FORMAT_FILE_PATH 	3

global	str		str_dvi;
global	str		str_tex;
global	str		str_log;
global	str		str_tfm;
global	str		str_fmt;
global	str		str_texput;

#ifdef INIT
void init_file (void);
#endif
