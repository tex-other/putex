void get_x_token (void);
void expand (void);
void insert_relax (void);

#define	TOP_MARK_CODE				0
#define	FIRST_MARK_CODE				1
#define	BOT_MARK_CODE				2
#define	SPLIT_FIRST_MARK_CODE		3
#define	SPLIT_BOT_MARK_CODE			4

#define	top_mark					cur_mark[TOP_MARK_CODE]
#define	first_mark					cur_mark[FIRST_MARK_CODE]
#define	bot_mark					cur_mark[BOT_MARK_CODE]
#define	split_first_mark			cur_mark[SPLIT_FIRST_MARK_CODE]
#define	split_bot_mark				cur_mark[SPLIT_BOT_MARK_CODE]

extern pointer cur_mark[];

extern int long_state;
extern pointer pstack[];

void macro_call (void);
void x_token (void);
