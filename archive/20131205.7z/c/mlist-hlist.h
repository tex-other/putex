global	qword	cur_c;
global	fnt		cur_f;
global	fourq	cur_i;
global	ptr		cur_mlist;
global	scal	cur_mu;
global	int		cur_size;
global	int		cur_style;
global	bool	mlist_penalties;

pointer clean_box (pointer p, int s);
void fetch (pointer a);

#define	new_hlist(N)			mem[nucleus(N)].i

void mlist_to_hlist (void);

void make_over (pointer q);
void make_under (pointer q);
void make_vcenter (pointer q);
void make_radical (pointer q);
void make_math_accent (pointer q);
void make_fraction (pointer q);
scaled make_op (pointer q);
void make_ord (pointer q);
void make_scripts (pointer q, scaled delta);
int make_left_right (pointer q, int style, scaled max_d, scaled max_h);

 extern int magic_offset;
