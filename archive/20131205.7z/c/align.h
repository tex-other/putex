void push_alignment (void);
void pop_alignment (void);

#define ALIGN_STACK_NODE_SIZE 5

#define u_part(A) mem[A + HEIGHT_OFFSET].i
#define v_part(A) mem[A + DEPTH_OFFSET].i
#define extra_info(A) info(A + LIST_OFFSET)

#define SPAN_CODE 128
#define CR_CODE 129
#define CR_CR_CODE CR_CODE + 1

#define SPAN_NODE_SIZE  2

#define preamble link(align_head)

extern pointer cur_align;
extern pointer cur_span;
extern pointer cur_loop;
extern pointer cur_head;
extern pointer cur_tail;
extern pointer align_pointer;

void init_align (void);
void get_preamble_token (void);
void align_peek (void);
void init_row(void);
void init_span (pointer p);
void init_col (void);
bool fin_col (void);
void fin_row (void);
void fin_align (void);
