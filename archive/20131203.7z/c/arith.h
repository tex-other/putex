#define	UNITY 0200000
#define	TWO 0400000

integer half (integer x);
scaled round_decimals (int k);
void print_scaled (scaled s);

extern bool arith_error;
extern scaled texremainder;

scaled nx_plus_y (integer n, scaled x, scaled y);
scaled x_over_n (scaled x, integer n);
scaled xn_over_d (scaled x, integer n, integer d);

#define	INF_BAD 10000 

halfword badness (scaled t, scaled s);
